# Pustaka Saya Android (APK gratis)

Proyek ini membungkus Pustaka Saya 4.0 HTML ke aplikasi Android WebView. Penyimpanan IndexedDB dan localStorage memakai origin aplikasi `https://appassets.androidplatform.net`, sehingga terpisah dari data yang sebelumnya tersimpan di Chrome.

## Build APK gratis dari HP Android
1. Buat akun GitHub dan repository baru bernama `pustaka-saya-android`.
2. Unggah seluruh isi folder proyek ini ke root repository (termasuk folder tersembunyi `.github`).
3. Buka tab **Actions** pada repository.
4. Pilih workflow **Build Pustaka Saya APK**, tekan **Run workflow**.
5. Setelah selesai, buka run yang berhasil, bagian **Artifacts**, unduh `Pustaka-Saya-APK`.
6. Ekstrak ZIP artifact, lalu instal `app-debug.apk`. Android mungkin meminta izin instalasi dari sumber tersebut.

## Penting
- APK belum dikompilasi di paket ini. GitHub Actions yang akan mengompilasinya.
- Build membutuhkan kuota GitHub Actions; untuk akun personal paket gratis biasanya tersedia kuota, tergantung kebijakan dan pemakaian akun.
- PDF.js di HTML masih dimuat dari jsDelivr, sehingga membuka PDF pertama kali memerlukan internet. Aplikasi shell dan koleksi tersimpan secara lokal.
- Data Chrome lama tidak otomatis pindah ke APK. Sebelum beralih, buka Pustaka Saya lama dan buat **Cadangan lengkap + PDF**. Setelah APK dipasang, impor cadangan tersebut. Simpan salinan cadangan di tempat aman.
- Aplikasi menggunakan WebView Android; tidak membuka tab Chrome terpisah.
